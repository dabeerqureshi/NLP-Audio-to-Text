from flask import Flask, request, render_template, jsonify
import os
import speech_recognition as sr
from googletrans import Translator
from pydub import AudioSegment
from pydub.playback import play
import numpy as np

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def convert_to_wav(filepath):
    """Convert audio file to WAV format."""
    audio = AudioSegment.from_file(filepath)
    wav_path = filepath.rsplit('.', 1)[0] + '.wav'
    audio.export(wav_path, format='wav')
    return wav_path

def preprocess_audio(filepath):
    """Normalize audio volume and reduce noise."""
    audio = AudioSegment.from_wav(filepath)
    
    # Normalize volume
    normalized_audio = audio.normalize()
    
    # Save preprocessed audio
    preprocessed_path = filepath.rsplit('.', 1)[0] + '_preprocessed.wav'
    normalized_audio.export(preprocessed_path, format='wav')
    
    return preprocessed_path

def transcribe_audio(filepath):
    """Transcribe audio from a WAV file."""
    recognizer = sr.Recognizer()
    
    # Adjust for ambient noise
    with sr.AudioFile(filepath) as source:
        recognizer.adjust_for_ambient_noise(source)
    
    try:
        with sr.AudioFile(filepath) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
            print(f"Transcribed Text: {text}")  # Debugging output
            return text
    except sr.UnknownValueError:
        return "Google Speech Recognition could not understand audio."
    except sr.RequestError as e:
        return f"Could not request results from Google Speech Recognition service; {e}"

def translate_text(text):
    """Translate text from Urdu to English."""
    translator = Translator()
    try:
        translation = translator.translate(text, src='ur', dest='en')
        print(f"Translated Text: {translation.text}")  # Debugging output
        return translation.text
    except Exception as e:
        return f"Translation error: {e}"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    try:
        # Convert file to WAV format
        wav_path = convert_to_wav(filepath)
        
        # Preprocess audio
        preprocessed_path = preprocess_audio(wav_path)
        
        transcribed_text = transcribe_audio(preprocessed_path)
        if "Google Speech Recognition" in transcribed_text:
            return jsonify({"error": transcribed_text})
        
        translated_text = translate_text(transcribed_text)
        if "Translation error" in translated_text:
            return jsonify({"error": translated_text})
        
        return jsonify({"transcribed_text": transcribed_text, "translated_text": translated_text})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
#improve the accuracy of this project so that I recognizes both English and urdu